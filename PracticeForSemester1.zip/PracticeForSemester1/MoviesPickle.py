import pickle #Pickle  is a better option for saving a dataframe. not only does pickle save faster but its takes up less space in the memory. pickles storage utilization is unaffected by file format, it is python specific(restricted to python). and unlike CSV's pickle preserves data types, where csv stores as comma separated values; some data may be lost depending on the data set
FILENAME = "movies.bin"

def write_movies(movies):
    with open(FILENAME, "wb") as file: #wb = write bytes
        pickle.dump(movies, file)  # serialization converts into a byte stream  
        

def read_movies():
    with open(FILENAME, "rb") as file: #read bytes
        movies = pickle.load(file) #loads our bin file un-pickle de-serialization converts data into an object
    return movies           

def list_movies():
    movies = read_movies()
    for i, movie in enumerate(movies, start=1):
        print(f"{i}. {movie[0]} ({movie[1]})")
    print() 

def add_movie():
    name = input("Name: ")
    year = input("Year: ")
    movie = [name, year]
    movie_list = read_movies()
    movie_list.append(movie)
    write_movies(movie_list)
    print(f"{name} was added.\n")

def delete_movie(movies):
    index = int(input("Number: ")) # get index to delete
    if index < 1 or index > len(movies): #if indez=x is less than one or the index is greater than the len of our movies 
        print("Invaild movie number.\n")
    else:
        movie = movies.pop(index - 1)
        write_movies(f"{movie[0]} was deleted. \n")
        print(f"{movie[0]} was deleted.\n")

def display_menu():
    print("The Movie List Program")
    print()
    print("COMMAND MENU")
    print("List - list all movies")
    print("Add - add a movie")
    print("Del - delete a movie")
    print("Exit - exit a program")
    print()

def main():
    display_menu()
    while True:
        command = input("Command: ")
        if command.lower() == "list":
            list_movies()
        elif command.lower() == "add":
            add_movie()
        elif command.lower() == "del":
            delete_movie()
        elif command.lower() == "exit":
            break
        else:
            print("Not a vaild commnd. Please Try again.\n")
    print("Bye")

#attempts to pickle unpickable objj
if __name__ == "__main__":
    main()

#only load pickle data that u trust as there could be shell scripts embedded in the file 
