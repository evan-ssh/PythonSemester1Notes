#tuple is a collection which is ordered and unchangable used to group together related data


student = ("Evan",20,"male")
print(student)

print(student.count("Evan")) #count is how many times the value appears
print(student.index(20)) #check index of value in tuple

for x in student: #iterate over tuple
    print(x)


if "Evan" in student: #check if in
    print(student)