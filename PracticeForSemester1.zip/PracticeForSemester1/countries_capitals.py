capitals = {"USA": "Washington D.C",
            "india": "New Delhi", "China": "Beijing", "Russian": "Moscow"}

#print(dir(capitals))
#print(help(capitals))
#print(capitals.get("Japan"))

#if capitals.get("Canada"): #check to see if keys in dictionary
#   print("This capital exist")
#else:
#    print("That capital does not exist")

capitals.update({"Germany": "Berlin"})#update existing key value pair or add a new one
#capitals.update({"USA": "CANADA"})
#capitals.pop("China")
capitals.popitem()#Clears last item added
#capitals.clear() clears dictionary

keys = capitals.keys() # returns all the keys in a dictionary
for key in capitals.keys():
    print(key)
#print(capitals)
#print(keys)

value = capitals.values()
for value in capitals.values():
    print(value)

items = capitals.items()
print(items)

for key, value in capitals.items():
    print(f"{key}: {value}")