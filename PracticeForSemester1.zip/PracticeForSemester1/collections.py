#collection = single "variable" used to store multiple values

#List = [] ordered and mutable - duplicates are allowed

#Set = {} unordered and immutable - duplicates but ADD/REMOVE allowed - duplicates are not allowed

#tuple = () ordered and immutable - duplicates are okay tuples are fasr

#============================================================LISTS==============================================================================#

#fruits = ["Apple", "Pear", "Orange", "Banana"]
#print(fruits[0]) #To access a specific index use the index operator [0] = Apple if the index is not in list it will raise an index error

#print(fruits[0:3])#print first three items in our list

#print(fruits[::-1]) # :: use step to choose every second item in our list or ::-1 to print the list backwards

#for fruit in fruits: #iterates over list our counter 'fruit' 
#    print(fruit)

#print(dir(fruits)) #Prints methods for list

#print(help(fruits))


#print("Apple" in fruits) #check if in and prints the boolean

#fruits.append("Grape") # adds grape to the end of the list
#print(fruits)
#fruits.remove("Pear")
#print(fruits)
#print(len(fruits[0])) #Prints how many letters are in an index
#fruits.count("Apple") # How many times something appears in a list apple = 1
#===============================================================================================================================================#

#============================================================Sets==============================================================================#
fruits = {"Apple", "Pear", "Orange", "Banana"} #If you add a second apple the set will still only display one apple as no duplicates

#print(dir(fruits))
#print(len(fruits))
#print("Grape" in fruits) #Grape is not within set therefor False is returned
#print(fruits[0]) #Set object is not subscriptable index opeator cannot be used within sets

#fruits.add("pineapple") add/appends
#fruits.remove("Apple") removes apple this is case sensitive so its best practice to use lower() beforehand
#fruits.pop() removes a random fruits from
#print(fruits)
#fruits.clear #removes everything in the set




#============================================================U==============================================================================#
networkchuck = ("chuck", 33, "coffee")

(name, age, drink) = networkchuck
print(name)
print(age)
print(drink)
