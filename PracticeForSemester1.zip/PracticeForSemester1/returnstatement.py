def multiply():#Functions send python values/objects back to the caller. These values/objects are know as the functions return value which u can store or prin 
    x = int(input("Enter first number: "))
    y = int(input("Enter second number: "))
    
    z = x * y
    return z

z = multiply()
print(z)
