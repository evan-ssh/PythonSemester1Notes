def get_letter_count(sentence, letter_dictonary):
    for letter in sentence:
        if letter in letter_dictonary:
            letter_dictonary[letter] = letter_dictonary[letter] + 1
        else:
            letter_dictonary[letter] = 1

def output_letter_count(letter_dictionary):
    for letter, count in letter_dictionary.items():
        print(f"{letter} - {count}")

def main():
    letter_dictionary = {}
    sentence = input("Enter the sentence")
    get_letter_count(sentence, letter_dictionary)
    output_letter_count(letter_dictionary)

if __name__ == "__main__":
    main()