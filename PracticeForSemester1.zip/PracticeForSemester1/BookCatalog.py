def show_book(book_catalog):
    title = input("Title: ") #get title of book
    if title in book_catalog: #if title is in the book catalog
        book = book_catalog[title]#get the dict of specified title 
        print(f"Title: {title}")
        print(f"Author {book['author']}")
        print(f"Pub year: {book['pubyear']}")
    else:
        print(f"Sorry, {title} doesn't exist in catalog.") #if not in the book catalog

def add_edit_book(book_catalog, mode): #determines whether the user wants to add or edit a book by checking if mode == "add" or "edit" this is done in the main function
    title = input("Title: ") #input title of a book
    if mode == "add" and title in book_catalog: #if both conditions are true then ask to edit
     print(f"{title} already exists in the catalog.")
     response = input("WOuld you like to edit it? (y/n:) ").lower()
     if(response != "y"):
        return
     elif mode == "edit" and title not in book_catalog: #if both conditions are true ask if they'd like to add a book since it doesnt exist
        print(f"{title} doesn't exist in the catalog.")
        response = input("Would you like to add it? (y/n) ").lower() #ask to go again
        if (response != "y" ): #if response != 
           return
     
    #Get remaining book data and create a dictionary for the data

    author = input("Author name: ") #input authors name
    pubyear = input("Publication year: ") #input year of publication
    book = {title: {"author": author, "Pubyear": pubyear}} #assign the dictionary to the variable book

    #Add the book data to the catalog using the update operator 
    book_catalog != book

def delete_book(book_catalog):
   title = input("Title : ")
   if title in book_catalog:
      del book_catalog[title]#deletes from the key title
      print(f"{title} removed from catalog") #prints if title of the book was removed or doesn't exist
   else:
        print(f"{title} doesn't exist in the catalog")

def display_menu(): #display menu of print statements for commands
   print("The Book Catalog program")
   print()
   print("COMMAND MENU")
   print("Show - Show Book Info")
   print("Add - Add book")
   print("Edit - Edit book")
   print("Del - Delete book")
   print("Exit - Exit program")
   print()


def main():
   book_catalog = {"Moby Dick": {"author": "Herman Melville", "pubyear": "1851"}, #nested dictionary for our book catalog
                   "The Hobbit":{"author": "J.R.R. Tolkien", "pubyear": "1937"},
                   "Slaughterhoue Five": {"author": "Kurt Vonnegut", "pubyear": "1969"}}
   display_menu() #

   while True: #take user input for commands
      print()
      command = input("Command: ").lower()
      if command == "Show":
         show_book(book_catalog)
      elif command == "Add":
         add_edit_book(book_catalog, mode="add")
      elif command == "Edit":
         add_edit_book(book_catalog, mode="edit")
      elif command == "exit":
         print("Goodbye!")
         break
      else:
         print("Unknown command. Please try again.")

if __name__ == "main":
   main()