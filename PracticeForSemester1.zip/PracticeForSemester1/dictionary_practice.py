
def main():
   students_marks = {"Evan":50,
      "Brandon":60,
      "Kevin":80,
         "Terrence": 90}
   while True:

      display_menu()
      try:
         user_command = int(input("Enter number for command"))
         if user_command == 1:
            show_grades(students_marks)
         elif user_command == 2:
            student_pass_fail(students_marks)
         elif user_command == 3:
            add_student(students_marks)
         elif user_command == 4:
               break
         else:
            print("Enter proper key for a command")
      except ValueError:
       print("Enter vaild number for a command")

def display_menu():
   print(f"\nStudent database")
   print(f"Commands:")
   print("1 - Check who failed/passed")
   print("2 - Enter new student ")
   print("3 - Add a student to the database")
   print("4 - Exit Program")


def show_grades(students_marks):
   for key, value in students_marks.items():
      print((f"Student: {key} Grade: {value}"))
      
def student_pass_fail(students_marks):
   for key, value in students_marks.items():
      if value < 75:
         print(f"{key}-Fail")
      else:
         print(f"{key}-Pass")
         
      

def add_student(students_marks):
   while True:
      try:
         student = input("enter name of student(press exit to cancel)")
         if student.lower() == "exit":
               print(f"Exiting adding student")
               break 

         if not student:
            print("student name cannot be empty")
            continue
      
         if student in students_marks:
          duplicate_continue = input("continuing will override the current students grade")
          if duplicate_continue.lower() in ["n", "no"]:
            continue
       
         else:
            print(f"Student: {student}")       

         student_grade = int(input("enter a grade for the student"))
         if student_grade < 0 or  student_grade > 100:
            print("Enter a grade between (0 - 100)")
            continue
         else:
            students_marks.update({student: student_grade})
            print(f"\n {student} added with grade {student_grade}.")
            show_grades()
      except ValueError:
         print("Invalid input. Please enter a valid number for the grade.")
   


               
if __name__ == "__main__":
    main()     
      





#print(dir(grades)) #dunder methods of dicitonarys 

#print(help(grades)) # help function for dictionary

#print(grades.get("evan")) grabs value for a key

#print(grades.get("kevin"))# if key not in dict then value of none is returned

#if grades.get("evan"): 
 #   print("Evan completed his test") #see if key is in dict and print for circumstance
#else:
 #   print("Evan did not complete his test")

#grades.update({"jacob": "80"})#using the update method you can insert a new key value pair or change an existin pair
#print(grades)


#grades.update({"evan": "80"})
#print(grades)

#grades.pop("evan") removes key from the dict
#print(grades)

#grades.update({"austin": "60"}) pop item removes the last pair that was added
#print(grades)
#grades.popitem()
#print(grades)

#grades.clear() clears the entire dictionary
#print(grades)


#keys = grades.keys() use this to get all keys in dict
#print(keys)

#for key in grades.keys(): iterate over dict and print all keys
#   print(key)


#values = grades.values()
#print(values)


#for value in grades.values(): print all values
#    print(value)

#items = grades.items() both key and values
#print(items)

#for key, value in grades.items():
   # print(f"{key}: {value}")

