def add_bike():
    bike_dictionary = {}

    while True:
        name = input("Enter the name for the bike")
        if name.lower == "done":
            break
        else:
            age = int(input("Enter the age of the bike"))
            speeds = int(input("Enter the amount of gears"))
            bike_type = input("Enter the brand of bike")
            data = {}
            data["age"] = age
            data["speeds"] = speeds
            data["type"] = bike_type
            bike_dictionary["name"] = data
    return bike_dictionary

def print_bike(bike_dictionary):
    bike_name = input("enter name of bike to see info of")
    if bike_name in bike_dictionary:
        data = bike_dictionary[bike_name]
        print(f"Name: {bike_name}")
        print(f"Age: {data['age']}")
        print(f"type: {data['type']}")
        print()
    else:
        print(f"Bike {bike_name} is not in dictionary")
    
def display_bikes(bike_dictionary):
    for bike_name in bike_dictionary:
        data = bike_dictionary[bike_name]
        print(f"Name: {bike_name}")
        print(f"Age: {data['age']}")
        print(f"Type: {data['type']}")
        print()
def main():
    bike_dictionary = add_bike()
    display_bikes(bike_dictionary)
    print_bike(bike_dictionary)

if __name__ == "__main__":
    main()