#fruits = ["apple", "orange", "banana", "pear"]
#vegetables = ["celery", "carrots", "potatos"]
#meats = ["chicken", "fish", "turkey"]

#groceries = [fruits,vegetables,meats]
#print(groceries)

#groceries = [["apple","orange","banana","pear"],
           # ["celery", "carrots", "potatos"], 
           # ["chicken", "fish", "turkey"]]

#for food in groceries: #prints
#   for row in food:
#    print(row, end=' ') 

numpad = ((1,2,3),
         (4,5,6),
         (7,8,9),
        ("*", 0, "#"))
#for every number in numpad
for numbers in numpad: #creates a grid since the print statement outside the nested loop prints \n

    for num in numbers:
     print(num, end=" ")
    print()

#