import csv


def load_recipes():
    recipe_data = {}
    with open("RecipesData.csv") as file:
        reader = csv.reader(file)
        for row in reader:
            if row[0] in recipe_data:
                recipe_data[row[0]][row[1]] = [row[2]]
            else: 
                recipe_data[row[0]] = {}
                recipe_data[row[0]][row[1]] = row[2]
    return recipe_data

def print_recipe(name, ingredients):
    print(name)
    print("Ingredients")
    for ingredient, amount in ingredients.items():
        print(f"{ingredient}, {amount}")

def main():
    recipe_data = load_recipes()

    while True:
        recipe = input("Enter the name of the recipe to lookup, 'done' to exit")
        if recipe == "done":
            break
        if recipe in recipe_data:
            print_recipe(recipe, recipe_data[recipe])
        else:
            print(f"{recipe} is not availble")
if __name__ == "__main__":
    main()
