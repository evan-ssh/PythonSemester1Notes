

def main():
    print("The Word Counter Program")
    print()

    filename = "gettysburg_address.txt"

    words = get_words_from_file(filename) #get the list of words
    word_count = count_words(words)
    display_word_count(word_count)

def get_words_from_file(filename):
    with open(filename) as file: #Open file
        text = file.read() #read file as a string and assign it to text
    text = text.replace("\n", "") #remove newline character
    text = text.replace(",", "") #remove comma
    text = text.replace(".", "") #remove period
    text = text.lower() #convert the string from our file to lowercase

    words = text.split(" ") #converts str to list and puts a space between each word
    return words

def count_words(words): 
    word_count = {}
    for word in words:
        if word in word_count:
            word_count[word] += 1 #increment count for word
        else:
            word_count[word] = 1 #add word with count of 1
    return word_count

def display_word_count(word_count):
    words = list(word_count.keys()) #creates a list in our function from wordcount dictionary
    words.sort(key=str.lower) # case insensitive sorting, sorts by their lowercase values
    for word in words: #for words in our words list
        count = (word_count.keys()) #assign the keys of word count to count
        print(word, "=", count)#prints the words and count


if __name__ == "main":
    main()