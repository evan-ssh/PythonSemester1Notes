def get_price():
    while True:
        try:
            price = float(input("Enter Price: "))
            return price
        except ValueError:
            print("Invaild decimal number. Try again")
    
def get_quantity():
    while True:
        try:
            quantity = int(input("Enter Quantity:"))
            return quantity
        except ValueError:
            print("Invaild interger. Please try again.")

def main():
    print("The Total Calculator Program\n")

    #get the price and quantity
    price = get_price()
    quantity = get_quantity()

    #calculate the total
    total = price * quantity

    #Show results

    print("Price: ", price)
    print("Quantity:", quantity)
    print("Total:", total)

if __name__ == "__main__":
    main()

