import random
def spin_row():
 symbols = ["🍒","👻","🍋","🍆","🍄"]

 return [random.choice(symbols)for _ in range(3)]
def print_row(row):
    print("-----------------")
    print(" | ".join(row))
    print("-----------------")

def get_payout(row, bet):
    if row[0] == row[1] == row[2]:
     if row[0] == "🍒":
        return bet * 2
     elif row[0] == "👻":
        return bet * 2
     elif row[0] == "🍋":
        return bet * 3
     elif row[0] == "🍆":
        return bet * 3
     elif row[0] == "🍄":
        return bet * 5 
    

def main():
    is_running = True
    
    print("------------------")
    print("welcome to the slots ")
    print("SYMBOLS:🍒👻🍋🍆🍄")
    print("------------------")

    while is_running:
        balance = 100
        print(f"Your Current bank:{balance}")
        bet = int(input("Enter amount to bet:")) 

        if bet > balance:
            print("Insufficent funds ")
            continue
        if bet <= 0:
            print("Bet must be greater than 0")
            continue
        balance -= bet 

        row = spin_row()
        print("Spinning...\n")
        print_row(row)

        payout = get_payout(row, bet)

        if payout > 0:
          print(f"BIG WIN!!! ${payout}")
        else:
            (f"Sorry you lost Try Again!")

        balance += payout
        play_again = input("Would you like to continue playing?(Y/N)").lower()
        if play_again == "Y":
           continue
        elif play_again == "N":
            is_running = False
        else:
           print("Choose 'Y' or 'n'")
if __name__ == "__main__":
    main()