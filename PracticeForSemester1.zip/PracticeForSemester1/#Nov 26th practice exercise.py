#Nov 26th practice exercise


def main():
 while True:
    bracket_entry = {}
    new_players = biking_players()
    bracket_entry.update(new_players)
    print(bracket_entry)
    
       
        
        


def biking_players():
 while True: 
    try:
        name = input("Enter ur name ")
        print(f"Name:{name}")
        brand = input("Enter name of your bike ")
        print(f"Bike: {brand}")
        age = (input("How old is your bike in years "))
        print(f"Bike is {age} years old")
        add_another_player = input("Continue to next entry? (Yes/Y)").lower()
        if add_another_player != 'y':
         return {"Name": name, "Brand": brand, "Age": age}
        else:
           continue
        
    except Exception as e:
       print({e})
       
   

      
       

            
         
        
if __name__ == "__main__":
    main()

#bicycles["Name"] = name
#bicycles["Bike"] = bike 
#  #bicycles["Age"] = age