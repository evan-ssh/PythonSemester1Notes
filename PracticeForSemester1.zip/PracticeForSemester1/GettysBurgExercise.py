def main():
    filename = "gettysburg_address.txt"
    print("The Word Counter Program")

    #get words and unique words
    words = get_word(filename)
    unique_words = get_unique_words(words)

    #Display number of words and unique words
    print(f"Number of words = {len(words)}")
    print(f"Number of unique words = {len(unique_words)}")

    #display unique words and their word counts
    print("Unique Word Occurences: ")
    for word in unique_words:
        print(f" {word} = {words.count(word)}")

def get_word(filename):
    with open(filename) as file:
        text = file.read() #reads file as string\
    
    text  = text.replace("\n", "") #removes new line
    text  = text.replace(",", "") #removes comma
    text  = text.replace(".", "") #removes .
    text  = text.lower()

    words = text.split(" ") #coverts string to list
    words.sort() #sort alphabeticaly
    #print(words)
    return words
   
def get_unique_words(words):
    unique_words = []
    unique_words.append(words[0])

    for i in range(1, len(words)): # i is going to be the number that increases to whatever the length of words is
        if words[i] == words[i - 1]: #if current word == previous word not unique
            continue
        else:
            unique_words.append(words[i]) # if current word != previous word append to our unique words list
    return unique_words

if __name__ == "__main__":
    main()